package p1.Personatges;

import p1.Armas.Armas;

public class Guerrer extends Personatges {

    public Guerrer(String nom, double forca, double constitucio, double velocitat, double inteligencia,
            double sort, Armas arma, int niv, int pex) {

        super(nom, forca, constitucio, velocitat, inteligencia, sort, arma, niv, pex);

    }
}
