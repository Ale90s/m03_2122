package p1.Armas;

public class MartellCombat extends Armas {

    public MartellCombat() {
        super("MartellCombat", 15.0, 10.0);
    }

}
