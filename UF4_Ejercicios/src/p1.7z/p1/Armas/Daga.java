package p1.Armas;

public class Daga extends Armas {

    public Daga() {
        super("Daga", 10.0, 15.0);
    }

}
