package p1.Armas;

public class Puños extends Armas {

    public Puños() {

        super("Puños", 5.0, 5.0);

    }

}
