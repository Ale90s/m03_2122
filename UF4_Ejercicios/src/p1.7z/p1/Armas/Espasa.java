package p1.Armas;

public class Espasa extends Armas {

    public Espasa() {
        super("Espasa", 10.0, 10.0);
    }

}
